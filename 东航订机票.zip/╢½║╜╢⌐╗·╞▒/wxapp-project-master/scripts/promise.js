var Promise=require('../node_modules/core-js/library/es6/promise.js');
module.exports=Promise;
