# weChatApp-Run

###介绍
这是一个微信小程序Demo，主要功能是跑步。
现在还不够完善依然有很多问题，欢迎大家提出建议和意见。
大家也可以star收藏起来，以后会进行优化更新，大家一起学习进步。

###截图
![首页](https://github.com/alanwangmodify/weChatApp-Run/blob/master/pic/home.png)

![跑步页面](https://github.com/alanwangmodify/weChatApp-Run/blob/master/pic/run.png)

![侧滑返回](https://github.com/alanwangmodify/weChatApp-Run/blob/master/pic/slideback.png)

![侧滑返回](https://github.com/alanwangmodify/weChatApp-Run/blob/master/pic/slide.png)
