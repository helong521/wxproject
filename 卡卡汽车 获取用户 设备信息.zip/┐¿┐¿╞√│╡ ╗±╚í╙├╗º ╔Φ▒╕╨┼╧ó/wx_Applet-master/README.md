# wx_Applet
一个仿爱卡APP写的微信小程序。
