# 医药网原生APP的微信小程序DEMO
了解了一段时间的小程序之后，写了这么一个Demo，简单的实现了数据请求到UI呈现
基于 [Labrador](https://github.com/maichong/labrador) 框架构建。感谢labrador降低了我的学习成本
 - dist 项目编译后代码，在IDE新建项目时必须选择该文件夹预览
 - src 项目源代码目录，主要对此部分进行编辑

若果觉得对你有帮助，麻烦加星点赞
如需帮助，请加入QQ交流群 557162163交流

#实例Gif

![image](https://github.com/jiabinxu/yiyaowang-wx/blob/master/%E5%A3%B9%E8%8D%AF%E7%BD%911.gif)
 
 
 ## TODO
 - 集成redux管理数据状态
 - 完成购物车的一些操作
