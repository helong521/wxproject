import assert from 'assert';

//测试 add() 函数
export function testAdd(exports) {
  assert(exports.add(1, 1) === 2);
}
