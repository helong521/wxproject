import assert from 'assert';

export async function onLoad(c, next) {
  next();
}
