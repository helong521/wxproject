export default function* startupSaga() {
  console.log('startup');
}
