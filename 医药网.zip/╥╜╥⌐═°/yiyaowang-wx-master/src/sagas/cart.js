import wx from 'labrador';

export function addSaga() {
  wx.showToast({ title: '添加成功' });
}
