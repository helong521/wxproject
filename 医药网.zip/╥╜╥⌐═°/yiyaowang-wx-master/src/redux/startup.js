import { createAction } from 'redux-actions';

export const STARTUP = 'STARTUP';

export const startup = createAction(STARTUP);
